//1.Introduccion a Javascript
//Ejercicio 2 
console.log("1. Introducción a Javascript");
console.log( "Ejercicio 2: ");

let a = 5;
let b = 10;
let c = a + b;

console.log("La suma de a y b es: " +c);

//Ejercicio 3 
console.log( "Ejercicio 3: ");
let nombre = prompt("¿Cuál es tu nombre?");

console.log("Hola," + nombre + "!");


//-------------------------------------------------------
//2. Operadores lógicos y condicionales
//Ejercicio 1
console.log("2. Operadores lógicos y condicionales");
console.log( "Ejercicio 1: ");

let a1 = 29;
let b1 = 20;
let c1 ;

if (a1 > b1) {
    c1 = a1;
    console.log("El valor mayor es: " + c1);
} else if (b1 > a1) {
    c1 = b1;
    console.log("El valor mayor es: " + c1);
} else {
    console.log("Ambos valores son iguales.");
}

//Ejercicio 2

console.log( "Ejercicio 2: ");
let numero = prompt("Ingresa un numero y te dire si es par o impar: ");

if(numero % 2 ===1) {
    console.log("El número " + numero + " es par." );
}else{
    console.log("El número " +numero+ " es impar.");
}


//-------------------------------------------------------
//3. Operadores de asignación y bucles 
//Ejercicio 1
console.log("3. Operadores de asignación y bucles");
console.log( "Ejercicio 1: ");

let bandera = 10
while (bandera > 0){
    console.log(bandera);
    bandera --;
}

//Ejercicio 2

console.log( "Ejercicio 2: ");

let numero1;

do{
numero1 = prompt("Ingresar un número mayor a 100: ");
numero1 = parseInt(numero1);

}while(numero1 <=100 || isNaN(numero1));

console.log("Ingresaste un número mayor a 100: " + numero1);


//-------------------------------------------------------
//4. Funciones de JavaScript 
//Ejercicio 1
console.log("4. Funciones de JavaScript");
console.log( "Ejercicio 1: ");

function esPar(num){
    return num % 2 ===0;
}

console.log("El número " +4+ " es par: " + esPar(4));
console.log("El número " +9+ " es par: " + esPar(9));

//Ejercicio 2
console.log( "Ejercicio 2: ");

let Ce = 30;
const convertirCelsiusAFahrenheit = (Ce) =>{
    return  Ce * 1.8 + 32;
};

let F = convertirCelsiusAFahrenheit (Ce);

console.log(Ce + "°C son equivalentes a " + F + "°F.");

//-------------------------------------------------------
//5. Objetos en JavaScript
//Ejercicio 1
console.log("5. Objetos en JavaScript");
console.log( "Ejercicio 1: ");

let persona = {
    nombre: 'Morena',
    edad: 20,
    ciudad: 'Mendoza',
    cambiarCiudad: function(nuevaciudad){
           this.ciudad = nuevaciudad;
    },
};
console.log("Persona: " + persona.nombre + ", Edad: " +persona.edad+ ", Ciudad: " +persona.ciudad + ".");
persona.cambiarCiudad("Buenos Aires");
console.log("Actualizada--> Persona: " + persona.nombre + ", Edad: " +persona.edad+ ", Ciudad: " +persona.ciudad + ".");

//Ejercicio 2
console.log( "Ejercicio 2: ");

let libro = {
    titulo: 'El Quijote',
    autor: 'Miguel de Cervantes Saavedra',
    anio: 1605,
    esAntiguo: function esAntiguo (anio) {
          let anioactual = new Date().getFullYear();
          let anios = anioactual - this.anio;   
          
          if (anios > 10) {
            console.log("El libro '" + this.titulo + "' es antiguo.");
        } else {
            console.log("El libro '" + this.titulo + "' no es antiguo.");
        }
    }
};
libro.esAntiguo();

//-------------------------------------------------------
//6. Arrays
//Ejercicio 1
console.log("6. Arrays");
console.log( "Ejercicio 1: ");

let numeros = [1,2,3,4,5,6,7,8,9,10]

let numerosmult = [];

for (let i =0; i < numeros.length; i++){
 numerosmult.push(numeros[i]* 2);
}

console.log("Números originales: " + numeros);
console.log("Números múltiplicados por 2: " +numerosmult);

//Ejercicio 2

let pares = [];

for (let i =1; i <= 20; i++){
    if(i % 2 === 0){
    pares.push(i);
    }
   }

console.log("Primeros 10 números pares: " +pares);

//-------------------------------------------------------
//7. Introduccion al DOM
//Ejercicio 1
console.log("7. Introduccion al DOM");
console.log( "Ejercicio 1: ");

function cambiarColor() {     
    let elementosP = document.getElementsByTagName('p');
    for (let i = 0; i < elementosP.length; i++) {
      elementosP[i].style.color = 'blue';
    }
}

//Ejercicio 2
console.log( "Ejercicio 2: ");

function mostrarAlerta() {
    let valor = document.getElementById('texto').value;
    alert("Has ingresado: " + valor);
}

//-------------------------------------------------------
//8. Eventos en DOM
//Ejercicio 1
console.log("8. Eventos en DOM");
console.log( "Ejercicio 1: ");

const lista = document.getElementById ("lista");
console.log(lista);

//Ejercicio 2
const campoTexto = document.getElementById('Campo');
        const btnDeshabilitar = document.getElementById('btnDeshabilitar');
        const btnHabilitar = document.getElementById('btnHabilitar');

        btnDeshabilitar.addEventListener('click', function() {
            campoTexto.disabled = true; 
        });

        btnHabilitar.addEventListener('click', function() {
            campoTexto.disabled = false; 
        });

//-------------------------------------------------------
//9. LocalStorage
//Ejercicio 1
console.log("9. LocalStorage");
console.log( "Ejercicio 1: ");

const formulario = document.getElementById('formulario');
const emailInput = document.getElementById('email');
const mensajeDiv = document.getElementById('mensaje');


function mostrarCorreo() {
    const correoGuardado = localStorage.getItem('correo');
    console.log("Correo guardado:", correoGuardado); 
    if (correoGuardado) {
        mensajeDiv.innerHTML = `
            <p>Correo guardado: ${correoGuardado}</p>
            <button id="eliminar">Eliminar Correo Guardado</button>
        `;
        
        document.getElementById('eliminar').addEventListener('click', function() {
            localStorage.removeItem('correo'); 
            mensajeDiv.innerHTML = '';
            console.log("Correo eliminado");
        });
    }
}

mostrarCorreo();


formulario.addEventListener('submit', function(event) {
    event.preventDefault(); 
    const correo = emailInput.value;
    localStorage.setItem('correo', correo); 
    console.log("Correo guardado en localStorage:", correo);
    mostrarCorreo(); 
    emailInput.value = ''; 
});

